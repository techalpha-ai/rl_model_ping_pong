"""Cartoonish rendering of a live TableTennisEnv match."""
import pygame
import math
from env import FIELD_W, FIELD_H, BALL_R
import theme

OFFSET_X = 0
OFFSET_Y = 0


def set_offset(x, y):
    global OFFSET_X, OFFSET_Y
    OFFSET_X, OFFSET_Y = x, y


def to_screen(x, y):
    return int(x + OFFSET_X), int(y + OFFSET_Y)


def draw_table(surf):
    rect = pygame.Rect(OFFSET_X, OFFSET_Y, FIELD_W, FIELD_H)
    theme.rounded_rect(surf, rect.inflate(20, 20), (255, 255, 255), radius=26)
    theme.rounded_rect(surf, rect, theme.TABLE, radius=18)
    pygame.draw.rect(surf, theme.TABLE_LINE, rect, width=4, border_radius=18)
    net_x = OFFSET_X + FIELD_W // 2
    dash_h = 14
    y = OFFSET_Y + 6
    while y < OFFSET_Y + FIELD_H - 6:
        pygame.draw.line(surf, theme.NET_COLOR, (net_x, y), (net_x, y + dash_h), 5)
        y += dash_h + 10
    for cx, cy in [(0, 0), (FIELD_W, 0), (0, FIELD_H), (FIELD_W, FIELD_H)]:
        pygame.draw.circle(surf, (255, 255, 255), to_screen(cx, cy), 6)


def draw_zone(surf, env, side, color):
    """Faint dashed rectangle showing where a racket is allowed to roam."""
    if side == 'left':
        x0, x1 = env.left_x_min, env.left_x_max
    else:
        x0, x1 = env.right_x_min, env.right_x_max
    y0, y1 = env.y_min, env.y_max
    tl = to_screen(x0 - env.paddle_r, y0 - env.paddle_r)
    w = (x1 - x0) + 2 * env.paddle_r
    h = (y1 - y0) + 2 * env.paddle_r
    zone_surf = pygame.Surface((int(w), int(h)), pygame.SRCALPHA)
    pygame.draw.rect(zone_surf, (*color, 28), (0, 0, w, h), border_radius=16)
    dash = 10
    x = 0
    while x < w:
        pygame.draw.line(zone_surf, (*color, 110), (x, 0), (min(x + dash, w), 0), 2)
        pygame.draw.line(zone_surf, (*color, 110), (x, h - 1), (min(x + dash, w), h - 1), 2)
        x += dash * 2
    y = 0
    while y < h:
        pygame.draw.line(zone_surf, (*color, 110), (0, y), (0, min(y + dash, h)), 2)
        pygame.draw.line(zone_surf, (*color, 110), (w - 1, y), (w - 1, min(y + dash, h)), 2)
        y += dash * 2
    surf.blit(zone_surf, tl)


def draw_paddle(surf, x, y, radius, color, dark):
    """Oval racket: visually wider than tall for a paddle-ish silhouette."""
    rx, ry = int(radius * 1.15), int(radius * 0.85)
    sx, sy = to_screen(x, y)
    shadow_rect = pygame.Rect(sx - rx, sy - ry + 4, rx * 2, ry * 2)
    pygame.draw.ellipse(surf, dark, shadow_rect)
    rect = pygame.Rect(sx - rx, sy - ry, rx * 2, ry * 2)
    pygame.draw.ellipse(surf, color, rect)
    pygame.draw.ellipse(surf, theme.TEXT_DARK, rect, width=2)
    # little highlight for a glossy cartoon look
    hl = pygame.Rect(sx - rx * 0.5, sy - ry * 0.6, rx * 0.5, ry * 0.35)
    pygame.draw.ellipse(surf, (255, 255, 255, 120), hl)


def draw_ball(surf, x, y, t):
    sx, sy = to_screen(x, y)
    pygame.draw.circle(surf, (210, 220, 230), (sx + 2, sy + 4), BALL_R)
    pygame.draw.circle(surf, theme.BALL_COLOR, (sx, sy), BALL_R)
    pygame.draw.circle(surf, theme.TEXT_DARK, (sx, sy), BALL_R, width=1)
    ang = t * 6
    ex = sx + int(3 * math.cos(ang))
    ey = sy + int(3 * math.sin(ang))
    pygame.draw.circle(surf, theme.BALL_SEAM, (ex, ey), 2)


def draw_score(surf, score_left, score_right, name_left="Left", name_right="Right"):
    cx = OFFSET_X + FIELD_W // 2
    y = OFFSET_Y - 46
    theme.draw_text(surf, f"{name_left}", (cx - 140, y), size=20, color=theme.RED_DARK, center=True)
    theme.draw_text(surf, f"{name_right}", (cx + 140, y), size=20, color=theme.BLUE_DARK, center=True)
    theme.draw_text(surf, f"{score_left}", (cx - 40, y - 2), size=34, color=theme.RED_DARK, center=True)
    theme.draw_text(surf, ":", (cx, y - 2), size=34, color=theme.TEXT_DARK, center=True)
    theme.draw_text(surf, f"{score_right}", (cx + 40, y - 2), size=34, color=theme.BLUE_DARK, center=True)


def draw_match(surf, env, t, name_left="Left", name_right="Right", show_zones=True):
    draw_table(surf)
    if show_zones:
        draw_zone(surf, env, 'left', theme.RED)
        draw_zone(surf, env, 'right', theme.BLUE)
    draw_paddle(surf, env.paddle_left_x, env.paddle_left_y, env.paddle_r, theme.RED, theme.RED_DARK)
    draw_paddle(surf, env.paddle_right_x, env.paddle_right_y, env.paddle_r, theme.BLUE, theme.BLUE_DARK)
    draw_ball(surf, env.ball_x, env.ball_y, t)
    draw_score(surf, env.score_left, env.score_right, name_left, name_right)
