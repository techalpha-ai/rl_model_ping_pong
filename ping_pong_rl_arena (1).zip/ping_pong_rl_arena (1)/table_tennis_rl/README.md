# 🏓 Ping Pong RL Arena

A light, cartoonish table-tennis game where you train your own AI paddlers
with reinforcement-learning-style self-play, then watch them battle each
other — or step in and play the champion yourself.

## Setup

```bash
pip install -r requirements.txt
python main.py
```

Requires Python 3.9+. No GPU or heavy ML frameworks needed — the "brains"
are tiny numpy neural networks trained with neuroevolution, so training
runs fast on any laptop.

## How it works

- **Environment** (`env.py`): a top-down table tennis physics sim.
  Rackets are **2D discs that roam a zone near their own baseline**
  (configurable, ~30-40% of the half-table) instead of being pinned to
  a vertical line — so positioning in both axes matters, not just
  height. Ball speeds up on rallies, bounces off the walls, and contact
  point on the racket changes the return angle and pace.
- **Agent** (`agent.py`): each AI is a tiny neural network (8 inputs:
  ball position/velocity + own & opponent racket position → 12 hidden
  → 9 actions: stay + 8 directions) stored as plain numpy arrays.
- **Trainer** (`trainer.py`): a step-drivable `LiveTrainer` that a game
  loop can call every frame — trains one model at a time via a genetic
  algorithm (selection, crossover, mutation) through self-play. Each
  new model has to beat a growing roster of previously trained models
  plus a baseline "ball-tracking" bot — a curriculum that keeps
  producing stronger players.
- **GUI** (`app.py`, `theme.py`, `renderer.py`): a full pygame
  interface, light/cartoon themed, with oval rackets and a dashed
  overlay showing each racket's legal roaming zone. No side-wall
  bounce — like real table tennis, a ball that goes wide (or long) is
  simply a fault, and the point goes to whoever *didn't* hit it out
  (an untouched serve that flies wide is a let and just replays).

## Features

- **Live Training** — pick how many models (4–6), population size, and
  a target step count (1–10 million). Then watch it happen: the exact
  match currently being used to evaluate an AI (vs the baseline
  "computer" bot, a pool-mate, or a previously trained model) renders
  live on screen, with a step counter climbing in real time toward your
  target. Speed controls (1x / 10x / 100x / 500x / TURBO) let you watch
  normal-speed rallies or fast-forward through millions of steps in
  well under a minute. Pause any time, or hit "Finish & Save" to stop
  early and keep whatever's trained so far.
- **Settings** — a dedicated screen to tune the physics used everywhere
  (racket roam-zone size, racket size, ball speed, points to win a
  match). Saved to `settings.json` and persists between runs.
- **Watch AI vs AI** — pick any two trained models and watch a live
  rally.
- **Play vs Top AI** — the model list is ranked by fitness, with 🏆 and
  🥈 marking the best two. Pick either one (or any other trained model)
  and play against it yourself — your racket follows your mouse
  directly (full 2D control, clamped to your roam zone), with arrow
  keys as an alternative.
- **Model List** — see every trained model and its fitness score, with
  a "Delete All Models" option (two-click confirm) for a clean slate.
- **Compatibility guard** — if you change physics settings that affect
  the network's input/output shape (or load models from an older
  version of this project), they're automatically flagged
  "(old version — retrain)" and skipped rather than crashing the game.

All trained models are saved under `models/*.npz` (plus `models/meta.json`
for fitness rankings), so they persist between runs — train once, then
come back and play anytime.

## Tips

- More steps / bigger population = stronger, but slower to train.
  Defaults (4 models, population 10, 2 million steps) finish in a
  minute or two on a normal laptop at TURBO speed.
- The oval racket's roaming zone is shown as a dashed rectangle during
  matches/training — that's the full range it can reach.
- Racket physics are simplified: contact is circle-based even though
  the racket is drawn as an oval, and there's no spin yet (planned as a
  future enhancement) — return angle/pace currently come from where on
  the racket the ball makes contact.
