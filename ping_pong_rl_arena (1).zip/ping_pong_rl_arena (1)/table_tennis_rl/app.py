import os
import json
import glob
import pygame

import theme
import renderer
from env import TableTennisEnv, FIELD_W, FIELD_H, ACTIONS, DEFAULT_PADDLE_R, DEFAULT_ROAM_FRACTION, DEFAULT_BALL_SPEED_INIT
from agent import Agent, HeuristicBot
from trainer import LiveTrainer

SPEED_PRESETS = [1, 10, 100, 500, 3000]
SPEED_LABELS = ["1x", "10x", "100x", "500x", "TURBO"]
DEFAULT_SPEED_INDEX = 3

WIDTH, HEIGHT = 1000, 720
PROJECT_DIR = os.path.dirname(__file__)
MODELS_DIR = os.path.join(PROJECT_DIR, "models")
META_PATH = os.path.join(MODELS_DIR, "meta.json")
SETTINGS_PATH = os.path.join(PROJECT_DIR, "settings.json")

DEFAULT_SETTINGS = {
    "roam_pct": 35,           # racket roams this % of the half-table (30-40 typical)
    "paddle_r": DEFAULT_PADDLE_R,
    "ball_speed": int(DEFAULT_BALL_SPEED_INIT),
    "points_to_win": 11,
}

# reverse lookup: (h,v) direction -> discrete action id, used for keyboard control
_DIR_TO_ACTION = {v: k for k, v in ACTIONS.items()}


def load_settings():
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH) as f:
                d = json.load(f)
                merged = dict(DEFAULT_SETTINGS)
                merged.update(d)
                return merged
        except Exception:
            pass
    return dict(DEFAULT_SETTINGS)


def save_settings(settings):
    with open(SETTINGS_PATH, "w") as f:
        json.dump(settings, f, indent=2)


def load_meta():
    if os.path.exists(META_PATH):
        try:
            with open(META_PATH) as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_meta(meta):
    os.makedirs(MODELS_DIR, exist_ok=True)
    with open(META_PATH, "w") as f:
        json.dump(meta, f, indent=2)


def model_is_compatible(path):
    try:
        d = __import__("numpy").load(path, allow_pickle=True)
        from agent import INPUT, HIDDEN, OUTPUT
        return d['w1'].shape == (INPUT, HIDDEN) and d['w2'].shape == (HIDDEN, OUTPUT)
    except Exception:
        return False


def list_models():
    """Returns list of dicts: name, path, fitness, compatible."""
    os.makedirs(MODELS_DIR, exist_ok=True)
    meta = load_meta()
    files = sorted(glob.glob(os.path.join(MODELS_DIR, "*.npz")))
    models = []
    for f in files:
        name = os.path.splitext(os.path.basename(f))[0]
        fit = meta.get(name, {}).get("fitness_vs_bot", None)
        models.append({
            "name": name, "path": f, "fitness": fit,
            "compatible": model_is_compatible(f),
        })
    models.sort(key=lambda m: (not m["compatible"], m["fitness"] is None, -(m["fitness"] or 0)))
    return models


class App:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Ping Pong RL Arena")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.state = "MENU"
        self.t = 0.0
        self.running = True
        self.select_ctx = {}
        self.pick_error = None
        self.settings = load_settings()
        self.build_menu()
        self.train_steppers = [
            theme.Stepper((60, 150), "Number of models", 4, 4, 6, 1),
            theme.Stepper((60, 200), "Population size", 10, 6, 16, 2),
            theme.Stepper((60, 250), "Target steps (millions)", 2, 1, 10, 1),
        ]
        self.settings_steppers = [
            theme.Stepper((60, 160), "Racket roam zone (%)", self.settings["roam_pct"], 30, 40, 5),
            theme.Stepper((60, 210), "Racket size (radius)", self.settings["paddle_r"], 16, 34, 2),
            theme.Stepper((60, 260), "Ball speed", self.settings["ball_speed"], 4, 10, 1),
            theme.Stepper((60, 310), "Points to win a match", self.settings["points_to_win"], 5, 15, 2),
        ]
        self.session = None
        self.speed_index = DEFAULT_SPEED_INDEX
        self.paused = False
        self.confirm_delete = False

    def env_kwargs(self):
        return {
            "roam_fraction": self.settings["roam_pct"] / 100.0,
            "paddle_r": self.settings["paddle_r"],
            "ball_speed_init": float(self.settings["ball_speed"]),
        }

    # ---------------------------------------------------------- menu
    def build_menu(self):
        cx = WIDTH // 2
        self.menu_buttons = [
            theme.Button((cx - 160, 195, 320, 54), "Train Models", theme.GREEN, theme.GREEN_DARK),
            theme.Button((cx - 160, 260, 320, 54), "Watch AI vs AI", theme.BLUE, theme.BLUE_DARK),
            theme.Button((cx - 160, 325, 320, 54), "Play vs Top AI (You)", theme.RED, theme.RED_DARK),
            theme.Button((cx - 160, 390, 320, 54), "Model List", theme.YELLOW, (214, 168, 60), text_color=theme.TEXT_DARK),
            theme.Button((cx - 160, 455, 320, 54), "Settings", (200, 190, 230), (150, 138, 190), text_color=theme.TEXT_DARK),
            theme.Button((cx - 160, 520, 320, 54), "Quit", (200, 200, 200), (160, 160, 160), text_color=theme.TEXT_DARK),
        ]

    def draw_menu(self):
        self.screen.fill(theme.BG)
        theme.draw_cloud_decor(self.screen, WIDTH, 110, self.t)
        theme.draw_text(self.screen, "🏓 Ping Pong RL Arena", (WIDTH // 2, 100), size=46,
                         color=theme.TEXT_DARK, center=True, shadow=True)
        theme.draw_text(self.screen, "Train little AI paddlers and challenge the champion!",
                         (WIDTH // 2, 148), size=19, color=theme.TEXT_MUTED, center=True)
        mouse = pygame.mouse.get_pos()
        for b in self.menu_buttons:
            b.update_hover(mouse)
            b.draw(self.screen)

    def handle_menu_click(self, pos, click):
        labels = ["Train Models", "Watch AI vs AI", "Play vs Top AI (You)", "Model List", "Settings", "Quit"]
        for b, label in zip(self.menu_buttons, labels):
            if b.clicked(pos, click):
                if label == "Train Models":
                    self.state = "TRAIN_SETUP"
                elif label == "Watch AI vs AI":
                    self.go_aivsai_setup()
                elif label == "Play vs Top AI (You)":
                    self.go_play_setup()
                elif label == "Model List":
                    self.confirm_delete = False
                    self.state = "MODEL_LIST"
                elif label == "Settings":
                    self.state = "SETTINGS"
                elif label == "Quit":
                    self.running = False

    # -------------------------------------------------------- settings
    def draw_settings(self):
        self.screen.fill(theme.BG)
        theme.draw_text(self.screen, "Settings", (60, 60), size=38, shadow=True)
        theme.draw_text(self.screen, "Tune the physics and match rules used everywhere in the game.",
                         (60, 105), size=17, color=theme.TEXT_MUTED)
        for s in self.settings_steppers:
            s.draw(self.screen)
        theme.draw_text(self.screen, "Racket roam zone: how far into the table each racket can",
                         (60, 370), size=15, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, "travel from its own baseline (shown as a dashed zone in matches).",
                         (60, 390), size=15, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, "Changes apply to new training sessions and new matches.",
                         (60, 420), size=15, color=theme.TEXT_MUTED)

        mouse = pygame.mouse.get_pos()
        self.btn_settings_save.update_hover(mouse)
        self.btn_settings_save.draw(self.screen)
        self.btn_settings_back.update_hover(mouse)
        self.btn_settings_back.draw(self.screen)
        if getattr(self, "_settings_saved_flash", 0) > 0:
            theme.draw_text(self.screen, "Saved!", (self.btn_settings_save.rect.centerx,
                             self.btn_settings_save.rect.top - 22), size=16, center=True, color=theme.GREEN_DARK)

    btn_settings_save = theme.Button((60, 480, 220, 54), "Save Settings", theme.GREEN, theme.GREEN_DARK)
    btn_settings_back = theme.Button((300, 480, 160, 54), "Back", (210, 206, 198), (180, 176, 168), text_color=theme.TEXT_DARK)

    def save_settings_from_ui(self):
        roam, r, speed, ptw = [s.value for s in self.settings_steppers]
        self.settings.update({"roam_pct": roam, "paddle_r": r, "ball_speed": speed, "points_to_win": ptw})
        save_settings(self.settings)
        self._settings_saved_flash = 90

    # ---------------------------------------------------- train setup
    def draw_train_setup(self):
        self.screen.fill(theme.BG)
        theme.draw_text(self.screen, "Train Models", (60, 60), size=38, shadow=True)
        theme.draw_text(self.screen, "Evolve a population of AI paddlers via self-play.",
                         (60, 105), size=18, color=theme.TEXT_MUTED)
        for s in self.train_steppers:
            s.draw(self.screen)
        info_y = 320
        n, pop, target_millions = [s.value for s in self.train_steppers]
        total_steps = target_millions * 1_000_000
        est_sec_turbo = total_steps / 40000.0
        theme.draw_text(self.screen, f"Will train {n} models, each learning against a growing",
                         (60, info_y), size=16, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, "roster of past champions (curriculum self-play).",
                         (60, info_y + 22), size=16, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, f"Target: {total_steps:,} total training steps.",
                         (60, info_y + 50), size=16, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, f"At TURBO speed that's roughly ~{max(3,int(est_sec_turbo))}s of real time "
                                      f"(slower at lower speeds, but you can watch every rally).",
                         (60, info_y + 72), size=15, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, f"Physics: {self.settings['roam_pct']}% roam zone, "
                                      f"racket size {self.settings['paddle_r']}, ball speed {self.settings['ball_speed']}, "
                                      f"first to {self.settings['points_to_win']} (edit in Settings).",
                         (60, info_y + 100), size=14, color=theme.TEXT_MUTED)

        mouse = pygame.mouse.get_pos()
        self.btn_start_train.update_hover(mouse)
        self.btn_start_train.draw(self.screen)
        self.btn_back.update_hover(mouse)
        self.btn_back.draw(self.screen)

    btn_start_train = theme.Button((60, 470, 260, 56), "Start Training", theme.GREEN, theme.GREEN_DARK)
    btn_back = theme.Button((340, 470, 160, 56), "Back", (210, 206, 198), (180, 176, 168), text_color=theme.TEXT_DARK)

    def start_training(self):
        n, pop, target_millions = [s.value for s in self.train_steppers]
        self.session = LiveTrainer(num_models=n, pop_size=pop,
                                    target_total_steps=target_millions * 1_000_000,
                                    max_steps_per_match=3000, points_to_win=self.settings["points_to_win"],
                                    save_dir=MODELS_DIR, **self.env_kwargs())
        self.speed_index = DEFAULT_SPEED_INDEX
        self.paused = False
        self.state = "TRAINING"

    def draw_training(self):
        self.screen.fill(theme.BG)
        s = self.session
        theme.draw_text(self.screen, "Live Training", (30, 20), size=30, shadow=True)
        theme.draw_text(self.screen, f"Model {s.model_index if not s.done else s.num_models} / {s.num_models}"
                                      f"   |   Generation {s.gen if not s.done else '-'}",
                         (30, 62), size=18, color=theme.TEXT_MUTED)
        theme.draw_text(self.screen, f"Total steps: {s.total_steps:,}", (30, 86), size=18, color=theme.TEXT_MUTED)

        if not s.done:
            renderer.set_offset((WIDTH - FIELD_W) // 2, 150)
            renderer.draw_match(self.screen, s.env, self.t, s.current_agent_label, s.current_opponent_label)
            theme.draw_text(self.screen, f"best fitness this model: {s.best_fit:.2f}",
                             (WIDTH // 2, HEIGHT - 190), size=16, center=True, color=theme.TEXT_MUTED)

            bar_w, bar_h = 700, 22
            bx, by = WIDTH // 2 - bar_w // 2, HEIGHT - 160
            theme.rounded_rect(self.screen, (bx, by, bar_w, bar_h), theme.PANEL, radius=11, border=2, border_color=theme.TEXT_MUTED)
            frac = s.progress_fraction()
            theme.rounded_rect(self.screen, (bx, by, int(bar_w * frac), bar_h), theme.GREEN, radius=11)
            theme.draw_text(self.screen, f"{frac*100:.1f}% of {s.target_total_steps:,} step target",
                             (WIDTH // 2, by + 34), size=15, center=True, color=theme.TEXT_MUTED)

            mouse = pygame.mouse.get_pos()
            bx0 = WIDTH // 2 - (len(SPEED_PRESETS) * 100) // 2
            self._speed_buttons = []
            for i, label in enumerate(SPEED_LABELS):
                r = pygame.Rect(bx0 + i * 100, HEIGHT - 110, 90, 40)
                sel = (i == self.speed_index)
                col = theme.GREEN if sel else theme.PANEL
                theme.rounded_rect(self.screen, r, col, radius=10, border=2, border_color=theme.TEXT_MUTED)
                theme.draw_text(self.screen, label, r.center, size=16, center=True,
                                 color=theme.WHITE if sel else theme.TEXT_DARK)
                self._speed_buttons.append((r, i))

            self.btn_pause.text = "Resume" if self.paused else "Pause"
            self.btn_pause.update_hover(mouse)
            self.btn_pause.draw(self.screen)
            self.btn_cancel_train.update_hover(mouse)
            self.btn_cancel_train.draw(self.screen)
        else:
            theme.draw_text(self.screen, "Training complete!", (WIDTH // 2, 150), size=34,
                             center=True, color=theme.GREEN_DARK, shadow=True)
            y = 210
            for r in sorted(s.results, key=lambda r: -r['fitness_vs_bot']):
                theme.draw_text(self.screen,
                                 f"{r['name']}: fitness vs bot = {r['fitness_vs_bot']:.2f}   "
                                 f"({r['generations']} generations, {r['steps']:,} steps)",
                                 (WIDTH // 2, y), size=18, center=True)
                y += 30
            theme.draw_text(self.screen, f"Total training steps this session: {s.total_steps:,}",
                             (WIDTH // 2, y + 20), size=18, center=True, color=theme.TEXT_MUTED)
            mouse = pygame.mouse.get_pos()
            self.btn_train_done.update_hover(mouse)
            self.btn_train_done.draw(self.screen)

    btn_pause = theme.Button((WIDTH // 2 - 210, HEIGHT - 55, 190, 46), "Pause",
                              theme.YELLOW, (214, 168, 60), text_color=theme.TEXT_DARK, size=18)
    btn_cancel_train = theme.Button((WIDTH // 2 + 20, HEIGHT - 55, 190, 46), "Finish & Save",
                                     (230, 120, 120), (200, 90, 90), size=18)
    btn_train_done = theme.Button((WIDTH // 2 - 110, HEIGHT - 90, 220, 56), "Back to Menu",
                                   theme.GREEN, theme.GREEN_DARK)

    # -------------------------------------------------------- model list
    def draw_model_list(self):
        self.screen.fill(theme.BG)
        theme.draw_text(self.screen, "Model List", (60, 50), size=38, shadow=True)
        models = list_models()
        if not models:
            theme.draw_text(self.screen, "No trained models yet. Go train some first!",
                             (60, 120), size=20, color=theme.TEXT_MUTED)
        else:
            y = 110
            for i, m in enumerate(models):
                card = pygame.Rect(60, y, WIDTH - 120, 52)
                theme.rounded_rect(self.screen, card, theme.PANEL, radius=14, border=2, border_color=theme.PANEL_SHADOW)
                if not m["compatible"]:
                    medal = "⚠️ "
                    label = f"{medal}{m['name']} (old version — retrain)"
                    theme.draw_text(self.screen, label, (80, y + 14), size=19, color=theme.TEXT_MUTED)
                else:
                    medal = "🏆 " if i == 0 else ("🥈 " if i == 1 else "")
                    fit_str = f"{m['fitness']:.2f}" if m["fitness"] is not None else "—"
                    theme.draw_text(self.screen, f"{medal}{m['name']}", (80, y + 14), size=21)
                    theme.draw_text(self.screen, f"fitness vs bot: {fit_str}", (card.right - 260, y + 16),
                                     size=17, color=theme.TEXT_MUTED)
                y += 62
        mouse = pygame.mouse.get_pos()
        self.btn_back_from_list.update_hover(mouse)
        self.btn_back_from_list.draw(self.screen)
        self.btn_delete_all.text = "Confirm delete?" if self.confirm_delete else "Delete All Models"
        self.btn_delete_all.enabled = bool(models)
        self.btn_delete_all.update_hover(mouse)
        self.btn_delete_all.draw(self.screen)

    btn_back_from_list = theme.Button((60, HEIGHT - 90, 200, 56), "Back", (210, 206, 198), (180, 176, 168), text_color=theme.TEXT_DARK)
    btn_delete_all = theme.Button((WIDTH - 300, HEIGHT - 90, 240, 56), "Delete All Models",
                                   (230, 120, 120), (200, 90, 90))

    def handle_model_list_click(self, pos, click):
        if self.btn_back_from_list.clicked(pos, click):
            self.confirm_delete = False
            self.state = "MENU"
        if self.btn_delete_all.clicked(pos, click):
            if self.confirm_delete:
                for f in glob.glob(os.path.join(MODELS_DIR, "*.npz")):
                    os.remove(f)
                if os.path.exists(META_PATH):
                    os.remove(META_PATH)
                self.confirm_delete = False
            else:
                self.confirm_delete = True

    # ---------------------------------------------------- AI vs AI setup
    def go_aivsai_setup(self):
        self.select_ctx = {"mode": "aivsai", "left": None, "right": None}
        self.pick_error = None
        self.state = "AIVSAI_SETUP"

    def draw_pick_screen(self, title, need_keys):
        """Generic model-picker used for AI vs AI (2 picks) & Play (1 pick)."""
        self.screen.fill(theme.BG)
        theme.draw_text(self.screen, title, (60, 40), size=32, shadow=True)
        models = list_models()
        self._pick_buttons = []
        if not models:
            theme.draw_text(self.screen, "No trained models yet. Go train some first!",
                             (60, 110), size=20, color=theme.TEXT_MUTED)
        else:
            y = 92
            for i, m in enumerate(models):
                card = pygame.Rect(60, y, WIDTH - 120, 50)
                hovered = card.collidepoint(pygame.mouse.get_pos()) and m["compatible"]
                col = theme.YELLOW if hovered else theme.PANEL
                theme.rounded_rect(self.screen, card, col, radius=14, border=2, border_color=theme.PANEL_SHADOW)
                if not m["compatible"]:
                    theme.draw_text(self.screen, f"⚠️ {m['name']} (old version — retrain)",
                                     (80, y + 13), size=18, color=theme.TEXT_MUTED)
                else:
                    medal = "🏆 " if i == 0 else ("🥈 " if i == 1 else "")
                    fit_str = f"{m['fitness']:.2f}" if m["fitness"] is not None else "—"
                    theme.draw_text(self.screen, f"{medal}{m['name']}", (80, y + 13), size=20)
                    theme.draw_text(self.screen, f"fitness: {fit_str}", (card.right - 220, y + 15),
                                     size=16, color=theme.TEXT_MUTED)
                    self._pick_buttons.append((card, m))
                y += 58

        sel_text = "  ".join(f"{k}: {v['name'] if v else '—'}" for k, v in self.select_ctx.items() if k in need_keys)
        theme.draw_text(self.screen, sel_text, (60, HEIGHT - 150), size=18, color=theme.TEXT_MUTED)
        if self.pick_error:
            theme.draw_text(self.screen, self.pick_error, (60, HEIGHT - 125), size=15, color=theme.RED_DARK)

        mouse = pygame.mouse.get_pos()
        self.btn_back_pick.update_hover(mouse)
        self.btn_back_pick.draw(self.screen)
        ready = all(self.select_ctx.get(k) for k in need_keys)
        self.btn_confirm_pick.enabled = ready
        self.btn_confirm_pick.update_hover(mouse)
        self.btn_confirm_pick.draw(self.screen)

    btn_back_pick = theme.Button((60, HEIGHT - 90, 200, 56), "Back", (210, 206, 198), (180, 176, 168), text_color=theme.TEXT_DARK)
    btn_confirm_pick = theme.Button((WIDTH - 260, HEIGHT - 90, 200, 56), "Start!", theme.GREEN, theme.GREEN_DARK)

    def handle_pick_click(self, pos, click, need_keys):
        for card, m in getattr(self, "_pick_buttons", []):
            if click and card.collidepoint(pos):
                self.pick_error = None
                if self.select_ctx["mode"] == "aivsai":
                    if self.select_ctx["left"] is None:
                        self.select_ctx["left"] = m
                    elif self.select_ctx["right"] is None:
                        self.select_ctx["right"] = m
                    else:
                        self.select_ctx["left"] = m
                        self.select_ctx["right"] = None
                else:
                    self.select_ctx["model"] = m
        if self.btn_back_pick.clicked(pos, click):
            self.state = "MENU"
        if self.btn_confirm_pick.clicked(pos, click) and all(self.select_ctx.get(k) for k in need_keys):
            try:
                if self.select_ctx["mode"] == "aivsai":
                    self.start_aivsai_match()
                else:
                    self.start_play_match()
            except Exception as e:
                self.pick_error = f"Couldn't load model: {e}"

    # ------------------------------------------------------- match logic
    def start_aivsai_match(self):
        left = Agent.load(self.select_ctx["left"]["path"])
        right = Agent.load(self.select_ctx["right"]["path"])
        self.match_env = TableTennisEnv(max_steps=1_000_000, points_to_win=self.settings["points_to_win"],
                                         **self.env_kwargs())
        self.match_env.reset(full=True)
        self.match_left_agent = left
        self.match_right_agent = right
        self.match_left_name = self.select_ctx["left"]["name"]
        self.match_right_name = self.select_ctx["right"]["name"]
        self.match_mode = "aivsai"
        self.state = "MATCH"

    def go_play_setup(self):
        self.select_ctx = {"mode": "play", "model": None}
        self.pick_error = None
        self.state = "PLAY_SETUP"

    def start_play_match(self):
        ai = Agent.load(self.select_ctx["model"]["path"])
        self.match_env = TableTennisEnv(max_steps=1_000_000, points_to_win=self.settings["points_to_win"],
                                         **self.env_kwargs())
        self.match_env.reset(full=True)
        self.match_left_agent = None  # human
        self.match_right_agent = ai
        self.match_left_name = "You"
        self.match_right_name = self.select_ctx["model"]["name"]
        self.match_mode = "play"
        self.state = "MATCH"

    def _human_action(self, env):
        """2D control: mouse position sets a direct target for the racket
        (clamped to the legal roam zone); arrow keys give discrete nudges
        as an accessible alternative."""
        keys = pygame.key.get_pressed()
        h = (-1 if keys[pygame.K_LEFT] else 0) + (1 if keys[pygame.K_RIGHT] else 0)
        v = (-1 if keys[pygame.K_UP] else 0) + (1 if keys[pygame.K_DOWN] else 0)
        if h != 0 or v != 0:
            return _DIR_TO_ACTION.get((h, v), 0)

        mx, my = pygame.mouse.get_pos()
        tx = mx - renderer.OFFSET_X
        ty = my - renderer.OFFSET_Y
        tx = max(env.left_x_min, min(env.left_x_max, tx))
        ty = max(env.y_min, min(env.y_max, ty))
        return (tx, ty)

    def update_match(self):
        env = self.match_env
        if self.match_left_agent is None:
            action_left = self._human_action(env)
        else:
            sL = env._get_obs('left')
            action_left = self.match_left_agent.act(sL)

        sR = env._get_obs('right')
        action_right = self.match_right_agent.act(sR)

        _, _, _, _, done, _ = env.step(action_left, action_right)
        if done:
            self.state = "MATCH_END"

    def draw_match(self):
        self.screen.fill(theme.BG)
        renderer.set_offset((WIDTH - FIELD_W) // 2, 140)
        renderer.draw_match(self.screen, self.match_env, self.t, self.match_left_name, self.match_right_name)
        hint = "Move your mouse to steer your racket (or use the arrow keys)" if self.match_left_agent is None \
            else "Watching two AIs rally it out..."
        theme.draw_text(self.screen, hint, (WIDTH // 2, HEIGHT - 40), size=18, color=theme.TEXT_MUTED, center=True)
        mouse = pygame.mouse.get_pos()
        self.btn_quit_match.update_hover(mouse)
        self.btn_quit_match.draw(self.screen)

    btn_quit_match = theme.Button((20, 20, 130, 44), "Menu", (210, 206, 198), (180, 176, 168),
                                   text_color=theme.TEXT_DARK, size=18)

    def draw_match_end(self):
        self.screen.fill(theme.BG)
        env = self.match_env
        winner = self.match_left_name if env.score_left > env.score_right else self.match_right_name
        theme.draw_text(self.screen, f"🎉 {winner} wins! 🎉", (WIDTH // 2, 180), size=44, center=True, shadow=True)
        theme.draw_text(self.screen, f"{self.match_left_name} {env.score_left} : {env.score_right} {self.match_right_name}",
                         (WIDTH // 2, 250), size=28, center=True, color=theme.TEXT_MUTED)
        mouse = pygame.mouse.get_pos()
        self.btn_rematch.update_hover(mouse)
        self.btn_rematch.draw(self.screen)
        self.btn_end_menu.update_hover(mouse)
        self.btn_end_menu.draw(self.screen)

    btn_rematch = theme.Button((WIDTH // 2 - 220, 340, 200, 56), "Rematch", theme.GREEN, theme.GREEN_DARK)
    btn_end_menu = theme.Button((WIDTH // 2 + 20, 340, 200, 56), "Main Menu", theme.BLUE, theme.BLUE_DARK)

    # ------------------------------------------------------------- loop
    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            self.t += dt
            if getattr(self, "_settings_saved_flash", 0) > 0:
                self._settings_saved_flash -= 1
            click = False
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    click = True
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.state in ("MATCH", "MATCH_END"):
                        self.state = "MENU"

            pos = pygame.mouse.get_pos()

            if self.state == "MENU":
                self.draw_menu()
                self.handle_menu_click(pos, click)

            elif self.state == "SETTINGS":
                self.draw_settings()
                if click:
                    for s in self.settings_steppers:
                        s.handle_click(pos)
                    if self.btn_settings_save.clicked(pos, click):
                        self.save_settings_from_ui()
                    if self.btn_settings_back.clicked(pos, click):
                        self.state = "MENU"

            elif self.state == "TRAIN_SETUP":
                self.draw_train_setup()
                if click:
                    for s in self.train_steppers:
                        s.handle_click(pos)
                    if self.btn_start_train.clicked(pos, click):
                        self.start_training()
                    if self.btn_back.clicked(pos, click):
                        self.state = "MENU"

            elif self.state == "TRAINING":
                s = self.session
                if s and not s.done and not self.paused:
                    was_done = s.advance(SPEED_PRESETS[self.speed_index])
                    if was_done:
                        meta = load_meta()
                        for r in s.results:
                            meta[r["name"]] = {"fitness_vs_bot": r["fitness_vs_bot"]}
                        save_meta(meta)
                self.draw_training()
                if click and s:
                    if s.done:
                        if self.btn_train_done.clicked(pos, click):
                            self.state = "MENU"
                    else:
                        for r, i in getattr(self, "_speed_buttons", []):
                            if r.collidepoint(pos):
                                self.speed_index = i
                        if self.btn_pause.clicked(pos, click):
                            self.paused = not self.paused
                        if self.btn_cancel_train.clicked(pos, click):
                            s.cancel()

            elif self.state == "MODEL_LIST":
                self.draw_model_list()
                if click:
                    self.handle_model_list_click(pos, click)

            elif self.state == "AIVSAI_SETUP":
                self.draw_pick_screen("Watch AI vs AI - pick two models", ["left", "right"])
                self.handle_pick_click(pos, click, ["left", "right"])

            elif self.state == "PLAY_SETUP":
                self.draw_pick_screen("Play vs AI - pick your opponent", ["model"])
                self.handle_pick_click(pos, click, ["model"])

            elif self.state == "MATCH":
                self.update_match()
                self.draw_match()
                if self.btn_quit_match.clicked(pos, click):
                    self.state = "MENU"

            elif self.state == "MATCH_END":
                self.draw_match_end()
                if self.btn_rematch.clicked(pos, click):
                    self.match_env.reset(full=True)
                    self.state = "MATCH"
                if self.btn_end_menu.clicked(pos, click):
                    self.state = "MENU"

            pygame.display.flip()

        pygame.quit()


if __name__ == "__main__":
    App().run()
