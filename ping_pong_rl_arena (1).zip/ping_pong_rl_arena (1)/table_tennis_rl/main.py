"""
Ping Pong RL Arena
-------------------
Run this to launch the game:

    python main.py

From the main menu you can:
  * Train Models      - evolve 4-6 AI paddlers via self-play (neuroevolution)
  * Watch AI vs AI     - pick any two trained models and watch them rally
  * Play vs Top AI     - challenge the #1 or #2 ranked model yourself
  * Model List         - see all trained models ranked by fitness
"""
from app import App

if __name__ == "__main__":
    App().run()
