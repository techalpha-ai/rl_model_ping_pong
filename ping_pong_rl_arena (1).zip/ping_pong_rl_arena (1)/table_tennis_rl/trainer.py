"""
LiveTrainer: a step-by-step-drivable neuroevolution trainer.

Unlike a fire-and-forget training loop, this exposes an `advance(n_steps)`
method that runs up to n_steps environment steps and then returns control.
That lets a pygame main loop call it every frame, render whatever match is
currently being played (an AI vs the baseline bot, another AI in its
population, or a previously trained model), and show a live, ever-growing
step counter -- so you can watch training happen in real time, at whatever
speed you like, all the way into the millions of steps.

Curriculum: model 1 trains against the baseline "computer" bot and its own
population. Model 2 additionally faces model 1. Model 3 faces models 1-2,
etc. -- so later models must beat an increasingly tough roster.
"""
import os
import numpy as np
from env import TableTennisEnv
from agent import Agent, HeuristicBot, crossover

MAX_GENERATIONS_SAFETY = 400  # hard safety cap so a model can't loop forever


def play_match(agent_left, agent_right, max_steps=900, points_to_win=5, env_kwargs=None):
    """Headless single match, used only for a quick final eval score."""
    env_kwargs = env_kwargs or {}
    env = TableTennisEnv(max_steps=max_steps, points_to_win=points_to_win, **env_kwargs)
    env.reset(full=True)
    total_left = 0.0
    done = False
    while not done:
        sL = env._get_obs('left')
        sR = env._get_obs('right')
        aL = agent_left.act(sL)
        aR = agent_right.act(sR)
        _, _, rL, _, done, _ = env.step(aL, aR)
        total_left += rL
    return total_left


def evaluate_fitness(agent, opponents, max_steps=900, points_to_win=5, env_kwargs=None):
    fit = 0.0
    for opp in opponents:
        fit += play_match(agent, opp, max_steps, points_to_win, env_kwargs)
    return fit / max(1, len(opponents))


class LiveTrainer:
    def __init__(self, num_models=4, pop_size=10, target_total_steps=2_000_000,
                 max_steps_per_match=3000, points_to_win=11, save_dir="models",
                 paddle_r=None, roam_fraction=None, ball_speed_init=None):
        self.num_models = num_models
        self.pop_size = pop_size
        self.target_total_steps = target_total_steps
        self.max_steps_per_match = max_steps_per_match
        self.points_to_win = points_to_win
        self.save_dir = save_dir
        self.env_kwargs = {}
        if paddle_r is not None:
            self.env_kwargs["paddle_r"] = paddle_r
        if roam_fraction is not None:
            self.env_kwargs["roam_fraction"] = roam_fraction
        if ball_speed_init is not None:
            self.env_kwargs["ball_speed_init"] = ball_speed_init
        os.makedirs(save_dir, exist_ok=True)

        self.bot = HeuristicBot()
        self.benchmark_pool = [self.bot]
        self.results = []
        self.total_steps = 0
        self.model_index = 1
        self.steps_budget_per_model = max(1, target_total_steps / num_models)
        self.done = False
        self.cancelled = False

        # per-match render state (read by the GUI)
        self.env = None
        self.current_agent_label = ""
        self.current_opponent_label = ""

        self._carry_fit = 0.0
        self._init_model_population()

    # ---------------------------------------------------------- lifecycle
    def _init_model_population(self):
        self.pop = [Agent(name=f"m{self.model_index}_g0_{i}") for i in range(self.pop_size)]
        self.gen = 0
        self.individual_index = 0
        self.gen_fits = []
        self.best_agent = None
        self.best_fit = -1e9
        self.model_steps_start = self.total_steps
        self._start_individual_matches()

    def _start_individual_matches(self):
        opp_pool = self.pop + self.benchmark_pool
        k = min(3, len(opp_pool))
        idxs = np.random.choice(len(opp_pool), size=k, replace=False)
        self.current_opponents = [opp_pool[i] for i in idxs]
        self.opponent_ptr = 0
        self._carry_fit = 0.0
        self._start_match()

    def _start_match(self):
        self.current_agent = self.pop[self.individual_index]
        self.current_agent_label = self.current_agent.name
        self.current_opponent = self.current_opponents[self.opponent_ptr]
        self.current_opponent_label = getattr(self.current_opponent, "name", "Computer")
        if self.current_opponent_label == "HeuristicBot":
            self.current_opponent_label = "Computer (basic bot)"
        self.env = TableTennisEnv(max_steps=self.max_steps_per_match, points_to_win=self.points_to_win,
                                   **self.env_kwargs)
        self.env.reset(full=True)
        self.match_reward = 0.0

    # -------------------------------------------------------------- step
    def advance(self, step_budget):
        """Run up to step_budget env steps this call. Returns self.done."""
        while step_budget > 0 and not self.done:
            sL = self.env._get_obs('left')
            sR = self.env._get_obs('right')
            aL = self.current_agent.act(sL)
            aR = self.current_opponent.act(sR)
            _, _, rL, _, match_done, _ = self.env.step(aL, aR)
            self.match_reward += rL
            self.total_steps += 1
            step_budget -= 1
            if match_done:
                self._on_match_done()
        return self.done

    def _on_match_done(self):
        self.opponent_ptr += 1
        if self.opponent_ptr < len(self.current_opponents):
            self._carry_fit += self.match_reward
            self._start_match()
        else:
            avg_fit = (self._carry_fit + self.match_reward) / len(self.current_opponents)
            self._carry_fit = 0.0
            self.gen_fits.append(avg_fit)
            self.individual_index += 1
            if self.individual_index < len(self.pop):
                self._start_individual_matches()
            else:
                self._on_generation_done()

    def _on_generation_done(self):
        fits = np.array(self.gen_fits)
        order = np.argsort(-fits)
        self.pop = [self.pop[i] for i in order]
        fits = fits[order]
        if fits[0] > self.best_fit:
            self.best_fit = float(fits[0])
            self.best_agent = self.pop[0].clone()
            self.best_agent.name = f"model_{self.model_index}"

        model_steps_done = self.total_steps - self.model_steps_start
        self.gen += 1
        if model_steps_done >= self.steps_budget_per_model or self.gen >= MAX_GENERATIONS_SAFETY:
            self._finish_model()
        else:
            survivors = self.pop[:max(2, self.pop_size // 2)]
            new_pop = [s.clone() for s in survivors]
            while len(new_pop) < self.pop_size:
                ia, ib = np.random.choice(len(survivors), 2, replace=False)
                child = crossover(survivors[ia], survivors[ib],
                                   name=f"m{self.model_index}_g{self.gen}_{len(new_pop)}")
                child.mutate(rate=0.2, scale=0.4)
                new_pop.append(child)
            self.pop = new_pop
            self.gen_fits = []
            self.individual_index = 0
            self._start_individual_matches()

    def _finish_model(self):
        if self.best_agent is None:
            self.best_agent = self.pop[0].clone()
            self.best_agent.name = f"model_{self.model_index}"
        eval_fit = evaluate_fitness(self.best_agent, [self.bot] * 3, max_steps=900, points_to_win=5,
                                     env_kwargs=self.env_kwargs)
        path = os.path.join(self.save_dir, f"model_{self.model_index}.npz")
        self.best_agent.save(path)
        self.results.append({
            "name": self.best_agent.name, "path": path,
            "fitness_vs_bot": eval_fit, "index": self.model_index,
            "generations": self.gen, "steps": self.total_steps - self.model_steps_start,
        })
        self.benchmark_pool.append(self.best_agent)
        self.model_index += 1
        if self.model_index > self.num_models or self.cancelled:
            self.done = True
        else:
            self._init_model_population()

    def cancel(self):
        """Stop training after finishing whatever model is currently in progress."""
        self.cancelled = True
        self.steps_budget_per_model = 0  # force current model to finish on next generation boundary

    # ------------------------------------------------------------ status
    def progress_fraction(self):
        if self.target_total_steps <= 0:
            return 0.0
        return min(1.0, self.total_steps / self.target_total_steps)
