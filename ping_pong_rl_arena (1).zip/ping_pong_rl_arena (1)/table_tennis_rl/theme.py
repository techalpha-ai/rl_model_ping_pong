"""Light, cartoonish visual theme shared across all screens."""
import pygame
import math

# --- palette -----------------------------------------------------------
BG = (255, 248, 231)          # warm cream background
PANEL = (255, 255, 255)
PANEL_SHADOW = (235, 226, 200)
TABLE = (176, 224, 255)       # pastel sky blue table
TABLE_LINE = (255, 255, 255)
NET_COLOR = (255, 255, 255)

RED = (255, 107, 107)
RED_DARK = (222, 74, 74)
BLUE = (77, 150, 255)
BLUE_DARK = (46, 111, 214)
YELLOW = (255, 209, 102)
GREEN = (110, 209, 148)
GREEN_DARK = (73, 173, 112)
TEXT_DARK = (60, 55, 70)
TEXT_MUTED = (150, 142, 130)
WHITE = (255, 255, 255)
BALL_COLOR = (255, 255, 255)
BALL_SEAM = (255, 140, 140)

FONT_NAME = None  # pygame default (rounded-ish, reads as friendly/cartoonish at size)


def font(size, bold=True):
    f = pygame.font.SysFont("Comic Sans MS,Arial,Verdana", size, bold=bold)
    return f


def draw_text(surf, text, pos, size=24, color=TEXT_DARK, bold=True, center=False, shadow=False):
    f = font(size, bold)
    if shadow:
        s = f.render(text, True, PANEL_SHADOW)
        r = s.get_rect()
        if center:
            r.center = (pos[0] + 2, pos[1] + 2)
        else:
            r.topleft = (pos[0] + 2, pos[1] + 2)
        surf.blit(s, r)
    surface = f.render(text, True, color)
    rect = surface.get_rect()
    if center:
        rect.center = pos
    else:
        rect.topleft = pos
    surf.blit(surface, rect)
    return rect


def rounded_rect(surf, rect, color, radius=16, border=0, border_color=None):
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    if border:
        pygame.draw.rect(surf, border_color or TEXT_DARK, rect, width=border, border_radius=radius)


class Button:
    def __init__(self, rect, text, color=BLUE, dark=BLUE_DARK, text_color=WHITE,
                 size=26, enabled=True, icon=None):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.color = color
        self.dark = dark
        self.text_color = text_color
        self.size = size
        self.enabled = enabled
        self.hovered = False

    def draw(self, surf):
        col = self.color if self.enabled else (210, 206, 198)
        dark = self.dark if self.enabled else (185, 180, 170)
        push = 4 if not self.hovered else 2
        shadow_rect = self.rect.move(0, 5)
        rounded_rect(surf, shadow_rect, dark, radius=16)
        top_rect = self.rect.move(0, 5 - push)
        rounded_rect(surf, top_rect, col, radius=16)
        draw_text(surf, self.text, top_rect.center, size=self.size,
                   color=self.text_color, center=True)

    def update_hover(self, mouse_pos):
        self.hovered = self.rect.collidepoint(mouse_pos) and self.enabled

    def clicked(self, mouse_pos, mouse_click):
        return self.enabled and mouse_click and self.rect.collidepoint(mouse_pos)


class Stepper:
    """A -/value/+ control for picking an integer within [lo, hi]."""
    def __init__(self, pos, label, value, lo, hi, step=1, width=260):
        self.label = label
        self.value = value
        self.lo, self.hi, self.step = lo, hi, step
        self.pos = pos
        self.width = width
        self.minus_rect = pygame.Rect(pos[0] + 170, pos[1], 34, 34)
        self.plus_rect = pygame.Rect(pos[0] + 170 + 90, pos[1], 34, 34)

    def draw(self, surf):
        draw_text(surf, self.label, (self.pos[0], self.pos[1] + 6), size=20, color=TEXT_DARK)
        rounded_rect(surf, self.minus_rect, YELLOW, radius=10)
        draw_text(surf, "-", self.minus_rect.center, size=24, center=True)
        rounded_rect(surf, self.plus_rect, YELLOW, radius=10)
        draw_text(surf, "+", self.plus_rect.center, size=24, center=True)
        val_rect = pygame.Rect(self.pos[0] + 170 + 40, self.pos[1], 46, 34)
        rounded_rect(surf, val_rect, PANEL, radius=10, border=2, border_color=TEXT_MUTED)
        draw_text(surf, str(self.value), val_rect.center, size=20, center=True)

    def handle_click(self, mouse_pos):
        if self.minus_rect.collidepoint(mouse_pos):
            self.value = max(self.lo, self.value - self.step)
            return True
        if self.plus_rect.collidepoint(mouse_pos):
            self.value = min(self.hi, self.value + self.step)
            return True
        return False


def draw_cloud_decor(surf, w, h, t):
    """A few soft floating circles for a playful backdrop."""
    for i in range(4):
        cx = (80 + i * 260 + 20 * math.sin(t / 2 + i)) % (w + 200) - 100
        cy = 40 + i * 8
        pygame.draw.circle(surf, (255, 255, 255), (int(cx), int(cy)), 26)
        pygame.draw.circle(surf, (255, 255, 255), (int(cx) + 24, int(cy) + 6), 20)
        pygame.draw.circle(surf, (255, 255, 255), (int(cx) - 22, int(cy) + 8), 18)
