"""
Lightweight numpy-only policy network + genetic operators.
No torch/tensorflow needed -> trains fast and stays dependency-light.

State is now 8-dim (ball x,y,vx,vy + self x,y + opponent x,y) and the
action space is 9-way (stay + 8 directions), matching the 2D roaming
racket physics in env.py.
"""
import numpy as np

INPUT = 8
HIDDEN = 12
OUTPUT = 9  # matches env.ACTIONS


class Agent:
    def __init__(self, weights=None, name="agent"):
        self.name = name
        if weights is None:
            self.w1 = np.random.randn(INPUT, HIDDEN) * 0.6
            self.b1 = np.zeros(HIDDEN)
            self.w2 = np.random.randn(HIDDEN, OUTPUT) * 0.6
            self.b2 = np.zeros(OUTPUT)
        else:
            self.w1, self.b1, self.w2, self.b2 = weights

    def act(self, state):
        h = np.tanh(state @ self.w1 + self.b1)
        o = h @ self.w2 + self.b2
        return int(np.argmax(o))

    def get_flat(self):
        return np.concatenate([self.w1.flatten(), self.b1.flatten(),
                                self.w2.flatten(), self.b2.flatten()])

    def set_flat(self, flat):
        i = 0
        n = INPUT * HIDDEN
        self.w1 = flat[i:i + n].reshape(INPUT, HIDDEN); i += n
        n = HIDDEN
        self.b1 = flat[i:i + n].copy(); i += n
        n = HIDDEN * OUTPUT
        self.w2 = flat[i:i + n].reshape(HIDDEN, OUTPUT); i += n
        n = OUTPUT
        self.b2 = flat[i:i + n].copy(); i += n

    def clone(self):
        a = Agent(name=self.name)
        a.set_flat(self.get_flat().copy())
        return a

    def mutate(self, rate=0.2, scale=0.4):
        flat = self.get_flat()
        mask = np.random.rand(*flat.shape) < rate
        flat[mask] += np.random.randn(int(mask.sum())) * scale
        self.set_flat(flat)

    def save(self, path):
        np.savez(path, w1=self.w1, b1=self.b1, w2=self.w2, b2=self.b2,
                  name=np.array(self.name))

    @staticmethod
    def load(path):
        d = np.load(path, allow_pickle=True)
        w1, b1, w2, b2 = d['w1'], d['b1'], d['w2'], d['b2']
        if w1.shape != (INPUT, HIDDEN) or w2.shape != (HIDDEN, OUTPUT):
            raise ValueError(
                f"Incompatible model shape {w1.shape}/{w2.shape} "
                f"(expected {(INPUT, HIDDEN)}/{(HIDDEN, OUTPUT)}) - retrain this model."
            )
        a = Agent(weights=(w1, b1, w2, b2))
        a.name = str(d['name'])
        return a


def crossover(a, b, name="child"):
    fa, fb = a.get_flat(), b.get_flat()
    mask = np.random.rand(*fa.shape) < 0.5
    child_flat = np.where(mask, fa, fb)
    c = Agent(name=name)
    c.set_flat(child_flat)
    return c


class HeuristicBot:
    """Simple 2D ball-tracking baseline opponent, used to bootstrap training."""
    name = "HeuristicBot"

    def act(self, state):
        # state (self-perspective, mirrored): ball_x,ball_y,bvx,bvy, self_x,self_y, opp_x,opp_y
        bx, by, sx, sy = state[0], state[1], state[4], state[5]
        dx = bx - sx
        dy = by - sy
        h = 0 if abs(dx) < 0.04 else (1 if dx > 0 else -1)
        v = 0 if abs(dy) < 0.04 else (1 if dy > 0 else -1)
        # map (h, v) in {-1,0,1}^2 back to the 9 discrete actions
        mapping = {
            (0, 0): 0, (0, -1): 1, (0, 1): 2, (-1, 0): 3, (1, 0): 4,
            (-1, -1): 5, (1, -1): 6, (-1, 1): 7, (1, 1): 8,
        }
        return mapping[(h, v)]
