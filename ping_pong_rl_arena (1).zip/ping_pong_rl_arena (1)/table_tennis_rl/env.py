"""
Core physics environment for the RL Table Tennis game.

Rackets are now 2D discs that can roam within a zone near their own
baseline (configurable, ~30-40% of the half-table depth) instead of
being pinned to a vertical line -- so positioning in both axes matters,
not just height.
"""
import numpy as np

FIELD_W = 900
FIELD_H = 520
BALL_R = 9

DEFAULT_PADDLE_R = 24
DEFAULT_ROAM_FRACTION = 0.35   # how far into the table a racket can roam,
                                # as a fraction of the half-table width (30-40% typical)
DEFAULT_BALL_SPEED_INIT = 6.0
BALL_SPEED_MAX = 15.0
BALL_SPEED_INC = 0.14
PADDLE_SPEED = 8.0
TABLE_MARGIN = 14  # gap between table edge and the closest a racket can get

# 9-way discrete action set: (dx, dy) unit-ish directions
ACTIONS = {
    0: (0, 0),    # stay
    1: (0, -1),   # up
    2: (0, 1),    # down
    3: (-1, 0),   # left
    4: (1, 0),    # right
    5: (-1, -1),  # up-left
    6: (1, -1),   # up-right
    7: (-1, 1),   # down-left
    8: (1, 1),    # down-right
}
DIAG = 0.70710678


class TableTennisEnv:
    def __init__(self, max_steps=1200, points_to_win=5, paddle_r=DEFAULT_PADDLE_R,
                 roam_fraction=DEFAULT_ROAM_FRACTION, ball_speed_init=DEFAULT_BALL_SPEED_INIT):
        self.max_steps = max_steps
        self.points_to_win = points_to_win
        self.paddle_r = paddle_r
        self.roam_fraction = roam_fraction
        self.ball_speed_init = ball_speed_init

        half_w = FIELD_W / 2
        self.left_x_min = TABLE_MARGIN + paddle_r
        self.left_x_max = self.left_x_min + roam_fraction * half_w
        self.right_x_max = FIELD_W - TABLE_MARGIN - paddle_r
        self.right_x_min = self.right_x_max - roam_fraction * half_w
        self.y_min = paddle_r
        self.y_max = FIELD_H - paddle_r

        self.reset(full=True)

    def reset(self, full=False):
        if full:
            self.score_left = 0
            self.score_right = 0
        self._reset_ball()
        self.paddle_left_x = self.left_x_min
        self.paddle_left_y = FIELD_H / 2
        self.paddle_right_x = self.right_x_max
        self.paddle_right_y = FIELD_H / 2
        self.steps = 0
        self.last_hit = None
        return self._get_obs('left')

    def _reset_ball(self, direction=None):
        self.ball_x = FIELD_W / 2
        self.ball_y = FIELD_H / 2
        self.last_hit = None
        angle = np.random.uniform(-0.35, 0.35)
        if direction is None:
            direction = np.random.choice([-1, 1])
        speed = self.ball_speed_init
        self.ball_vx = direction * speed * np.cos(angle)
        self.ball_vy = speed * np.sin(angle)

    def _get_obs(self, side='left'):
        """Normalized 8-dim state, mirrored for the right side so one
        policy can control either racket: [ball_x, ball_y, ball_vx, ball_vy,
        self_x, self_y, opp_x, opp_y]."""
        if side == 'left':
            bx, bvx = self.ball_x, self.ball_vx
            sx, sy = self.paddle_left_x, self.paddle_left_y
            ox, oy = self.paddle_right_x, self.paddle_right_y
        else:
            bx, bvx = FIELD_W - self.ball_x, -self.ball_vx
            sx, sy = FIELD_W - self.paddle_right_x, self.paddle_right_y
            ox, oy = FIELD_W - self.paddle_left_x, self.paddle_left_y
        by, bvy = self.ball_y, self.ball_vy
        state = np.array([
            (bx / FIELD_W) * 2 - 1,
            (by / FIELD_H) * 2 - 1,
            bvx / BALL_SPEED_MAX,
            bvy / BALL_SPEED_MAX,
            (sx / FIELD_W) * 2 - 1,
            (sy / FIELD_H) * 2 - 1,
            (ox / FIELD_W) * 2 - 1,
            (oy / FIELD_H) * 2 - 1,
        ], dtype=np.float32)
        return state

    def _apply_movement(self, side, action):
        """action is either an int (0-8 discrete direction) or a tuple
        (target_x, target_y) for direct positioning (used for human/mouse
        control)."""
        if side == 'left':
            x, y = self.paddle_left_x, self.paddle_left_y
            xmin, xmax = self.left_x_min, self.left_x_max
        else:
            x, y = self.paddle_right_x, self.paddle_right_y
            xmin, xmax = self.right_x_min, self.right_x_max

        if isinstance(action, tuple):
            x, y = action
        else:
            dx, dy = ACTIONS.get(int(action), (0, 0))
            if dx != 0 and dy != 0:
                dx *= DIAG
                dy *= DIAG
            x += dx * PADDLE_SPEED
            y += dy * PADDLE_SPEED

        x = float(np.clip(x, xmin, xmax))
        y = float(np.clip(y, self.y_min, self.y_max))

        if side == 'left':
            self.paddle_left_x, self.paddle_left_y = x, y
        else:
            self.paddle_right_x, self.paddle_right_y = x, y

    def _try_collide(self, side):
        if side == 'left':
            px, py = self.paddle_left_x, self.paddle_left_y
        else:
            px, py = self.paddle_right_x, self.paddle_right_y

        ddx = px - self.ball_x
        ddy = py - self.ball_y
        dist = (ddx * ddx + ddy * ddy) ** 0.5
        if dist > self.paddle_r + BALL_R:
            return False
        approaching = (self.ball_vx * ddx + self.ball_vy * ddy) > 0
        if not approaching:
            return False

        offset_y = float(np.clip((self.ball_y - py) / self.paddle_r, -1, 1))
        offset_x = float(np.clip((self.ball_x - px) / self.paddle_r, -1, 1))
        cur_speed = (self.ball_vx ** 2 + self.ball_vy ** 2) ** 0.5
        speed = min(cur_speed + BALL_SPEED_INC + 0.35 * abs(offset_x), BALL_SPEED_MAX)
        angle = offset_y * 0.55

        if side == 'left':
            self.ball_vx = abs(speed * np.cos(angle))
            self.ball_x = px + self.paddle_r + BALL_R + 1
        else:
            self.ball_vx = -abs(speed * np.cos(angle))
            self.ball_x = px - self.paddle_r - BALL_R - 1
        self.ball_vy = speed * np.sin(angle)
        self.last_hit = side
        return True

    def step(self, action_left, action_right):
        self.steps += 1
        self._apply_movement('left', action_left)
        self._apply_movement('right', action_right)

        self.ball_x += self.ball_vx
        self.ball_y += self.ball_vy

        reward_left = 0.0
        reward_right = 0.0

        hit = False
        if self.ball_vx < 0 and self._try_collide('left'):
            reward_left += 0.1
            hit = True
        elif self.ball_vx > 0 and self._try_collide('right'):
            reward_right += 0.1
            hit = True

        point_winner = None
        out_wide = self.ball_y < -20 or self.ball_y > FIELD_H + 20
        out_long = self.ball_x < -20 or self.ball_x > FIELD_W + 20

        if out_wide or out_long:
            # Real table tennis: going off the table (wide or long) is a
            # fault by whoever last hit it -- no wall bounce, the point
            # just ends. If nobody has touched it yet this rally (e.g. a
            # bad opening trajectory), it's a let: just replay the point.
            if self.last_hit == 'left':
                self.score_right += 1
                reward_left -= 1.0
                reward_right += 1.0
                point_winner = 'right'
                self._reset_ball(direction=1)
            elif self.last_hit == 'right':
                self.score_left += 1
                reward_right -= 1.0
                reward_left += 1.0
                point_winner = 'left'
                self._reset_ball(direction=-1)
            else:
                self._reset_ball()

        # shaping: gently encourage tracking the ball with your racket
        dl = ((self.paddle_left_x - self.ball_x) ** 2 + (self.paddle_left_y - self.ball_y) ** 2) ** 0.5
        dr = ((self.paddle_right_x - self.ball_x) ** 2 + (self.paddle_right_y - self.ball_y) ** 2) ** 0.5
        reward_left -= 0.0006 * dl / FIELD_W
        reward_right -= 0.0006 * dr / FIELD_W

        match_done = (self.score_left >= self.points_to_win or
                      self.score_right >= self.points_to_win or
                      self.steps >= self.max_steps)

        info = {'point_winner': point_winner, 'hit': hit}
        return self._get_obs('left'), self._get_obs('right'), reward_left, reward_right, match_done, info
